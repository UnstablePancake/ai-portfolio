# My AI journey

A log of what I have built with AI (mostly Claude) while working as a Tier 1 support technician. Each project lists the problem, what I built, how AI was used, and what I learned, including what I would do differently.

I hold the Microsoft AI-900 certification. My goal is to move from solving problems in support to building AI solutions that improve people's working day.

## Projects

| # | Project | Type | Built | What it shows |
|---|---------|------|-------|---------------|
| 1 | [Kveldsruletten](projects/01-kveldsruletten/) | Web app + Supabase + 2 dashboards | Sep–Oct 2026 | Full product loop: build, measure, keep a backlog, run scheduled AI agents |
| 2 | [App & Network Troubleshooter](projects/02-app-network-troubleshooter/) | Interactive tool + PowerShell/Bash scripts | Oct 2026 | Turning support know-how into a guided, OSI-based diagnosis tool |
| 3 | [Rollekonfliktfellen](projects/03-rollekonfliktfellen/) | Incident write-up | Sep 2026 | Using AI to turn a messy two-week incident into a reusable lesson |
| 4 | [Interview script: AI Engineer](projects/04-interview-ai-engineer/) | 15-min presentation script | Oct 2026 | Presenting my own AI work honestly, separating results from hypotheses |
| 5 | [IT Ops learning plan](projects/05-it-ops-learning-plan/) | Gap analysis (in progress) | Oct 2026 | Using AI to map a job ad to skills gaps and a plan |

Two more work artifacts (a daily backlog-review tool and a customer-specific guide) are not included, because they hold customer data.

## How I work with AI

- **Start small, with something I need myself.** Every project began with a concrete problem from my own day.
- **AI drafts, I decide.** I review and correct what the AI produces before it is used or shared.
- **Separate what I did from what I propose.** Claims of value are hypotheses until they are measured.
- **Keep risky tools read-only.** The backlog tool and the troubleshooter scripts only read; they change nothing.

## What I have learned so far

1. **Building is the easy part; proving value is the hard part.** I shipped the backlog tool without measuring time before and after, so I cannot say it saved time. Kveldsruletten got measurement from the start, which is how I found that zero nights had been saved (the save button sat two screens below the fold).
2. **Measure before you build.** Without a baseline there is nothing to compare against.
3. **The error message is often on the wrong layer.** Both the incident write-up and the troubleshooter come from the same lesson: find the lowest layer that breaks.
4. **Moving from "works for me" to "works for others"** needs testing, error handling, access control and maintenance. That is my next learning step.

## Tools

Claude (chat, artifacts, docs, dashboards, scheduled agents), Supabase (Postgres + REST), d3, PowerShell, Bash, n8n.

## Running the projects

Each HTML file opens directly in a browser. Kveldsruletten needs your own Supabase project URL and publishable key filled in (the originals were removed). The two dashboards were built on Claude's dashboard artifact type and only run inside it; they are kept here as source.
