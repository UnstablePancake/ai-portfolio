# Tier 1 App & Network Troubleshooter

An interactive service-desk tool that walks a technician through 17 checks across the 7 OSI layers when "the app doesn't work", and guesses which layer is broken.

**Live artifact:** https://claude.ai/artifact/7yxD69Jv72gLv8shVpdt6V (shared with my organization)

## Problem

Tier 1 tickets like "Teams/Outlook/the line-of-business app won't connect" are often escalated without a clear picture of where it breaks. The same checks get typed by hand every time, and the ticket note ends up thin.

## What I built

A single HTML page ([`index.html`](index.html)):

1. Pick **Windows or macOS** and a target (presets for Teams, Outlook, OneDrive, RDP and a SQL-backed app).
2. **Copy the auto-check script** (PowerShell or Bash) and run it on the affected computer. It is read-only and changes nothing.
3. **Paste the output back.** The script ends with a `T1RESULT:` line (base64 JSON) that fills in all 17 checks.
4. An **OSI pyramid** colours each layer, and the lowest failing layer is flagged as the likely fault, with a confidence level.
5. **Copy ticket note** produces a ready-made summary for the ticket.

Checks include: process, services, installed version, adapters, IPv4/APIPA, default gateway, gateway ping and ARP, DNS servers and lookup, TCP port, TLS certificate (including SSL-inspection detection), internet reachability, clock skew (Kerberos/MFA), proxy, traceroute and recent crash events.

## How AI was used

Claude wrote the page and both scripts from my troubleshooting routine. I steered which checks mattered at Tier 1, how VPN and ICMP filtering should be treated (not as faults when the port is open), and the wording of the verdicts.

## What I learned

- **Find the lowest broken layer.** Everything above it depends on it, so fixing it first saves time.
- **Avoid false alarms.** A blocked ping or a VPN tunnel gateway that doesn't answer is normal; the logic downgrades these when the TCP port test passes.
- **Make the output portable.** Encoding results as one copyable line made the round trip between the user's PC and the tool simple.
