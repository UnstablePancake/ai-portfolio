# Kveldsruletten

A date-night roulette for Grünerløkka, Oslo. One click draws a wine, a dinner (home or out), a place to go afterwards and an activity. You can lock what you like and redraw the rest, then save the night and rate it afterwards.

**Live artifact:** https://claude.ai/artifact/4zqvcFEcPG5dBP8fDuEwy6 (private)

## Problem

Choosing what to do on a night out takes longer than the night itself. I wanted a playful way to decide, with lists I could grow over time.

## What I built

| File | What it is |
|------|------------|
| [`index.html`](index.html) | The app. Plain HTML/JS, no framework. Filters by season, dinner mode and wine budget, with lock/redraw per card and a history with 1–5 hearts. |
| [`dashboards/maalinger.html`](dashboards/maalinger.html) | Measurement dashboard: steps from session to saved night, events per day, event types and "Take me there" clicks per place. |
| [`dashboards/backlogg.html`](dashboards/backlogg.html) | Backlog dashboard: issues from `BACKLOG.md` by priority, status and size, plus the scheduled Claude agents working on the repo. |

**Data:** Supabase tables `wines`, `dinners`, `places`, `activities` and `date_nights`, read and written over the REST API. Later versions added `events`, `place_clicks`, `shared_nights` and `share_responses` for measurement and sharing.

> The Supabase URL and key were removed from `index.html`. Fill in your own to run it.

## How AI was used

- Claude wrote the app and the Supabase schema from my description, and I iterated on design and features.
- Claude built both dashboards as live queries against Supabase, so the numbers stay current.
- Scheduled Claude agents (engineer, SEO, analysis) worked on the repo on a timer. I stopped the SEO and analysis runs on 16.10.2026 to focus on fixes.

## What I learned

- **Measuring changed the roadmap.** The dashboard showed zero saved nights. The reason was not lack of interest: saving needed an account and a group, and the save button sat almost two screen heights below the fold, behind four cards.
- **Consent-based tracking undercounts.** Tracking needs consent and respects Do Not Track / Global Privacy Control, so real traffic is higher than the numbers. Clicks and shares are logged without identifiers, which makes them a useful cross-check.
- **Fixes cause regressions.** The backlog dashboard flags regressions introduced by the fixes on 15.10.2026, and they are taken before new features.
- **Agents need supervision.** Scheduled agents are useful, but I had to stop runs that were not paying off.
