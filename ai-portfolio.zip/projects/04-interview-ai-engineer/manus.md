# Manus: Intervju AI Engineer

*11.10.2026*

## Slik bruker du manuset

Manuset er beregnet til 15 minutter med rolig tempo, rundt 120 ord i minuttet. Hver del slutter med en overgang i kursiv som leder til neste lysbilde. Tekst merket [BEKREFT] er forslag du må kjenne deg igjen i før du bruker dem.

| Lysbilde | Tema | Tid | Klokka ved slutt |
|---|---|---|---|
| 1 | Fra support til AI Engineer | 1 min | 1:00 |
| 2 | Hva ved rollen motiverer meg | 2 min | 3:00 |
| 3 | Hva jeg tar med meg, og hva jeg må lære | 1,5 min | 4:30 |
| 4 | Tre muligheter for en norsk SMB | 3 min | 7:30 |
| 5 | Startpunkt og hvordan undersøke verdien | 2 min | 9:30 |
| 6 | Backlog-verktøyet i Claude | 3 min | 12:30 |
| 7 | WOW og kultur | 1,5 min | 14:00 |
| 8 | Hva jeg ønsker å bidra med | 1 min | 15:00 |

## 1. Fra support til AI Engineer · 1 min

Hei, og takk for at jeg får presentere. Jeg heter Hassan Sadiq, og jeg jobber som Support Technician på Incidents, Tier 1 her i Digiflow. Hverdagen min består av feilsøking, brukerveiledning, dokumentasjon og eskalering. Der møter jeg konkrete problemer og behov hos brukerne.

Interessen min for AI har vokst gjennom å lage løsninger selv. Jeg har tatt AI-900-sertifiseringen, og jeg har laget noen egne prosjekter. De har gitt meg lyst til å utforske dette videre.

Det er veien dere ser nederst på lysbildet: fra support, via egne prosjekter, til rollen som AI Engineer. Hovedbudskapet mitt i dag er: fra å løse problemer i support til å utvikle AI-løsninger som forbedrer arbeidshverdagen. Jeg er tidlig i dette. Derfor skiller jeg underveis mellom det jeg har gjort, og det jeg foreslår.

*Overgang: Så hvorfor akkurat denne rollen? Jeg vil starte med det som motiverer meg.*

## 2. Hva ved rollen motiverer meg · 2 min

Jeg har valgt ut to arbeidsoppgaver i rollen [BEKREFT: forslag, ikke sjekket mot stillingsannonsen. Bytt til annonsens ordlyd hvis den avviker], og jeg har koblet hver av dem til noe jeg har gjort selv.

Den første er å utvikle AI-løsninger som løser konkrete behov. Det som motiverer meg her, er å ta utgangspunkt i en praktisk utfordring og lage noe som blir brukt i arbeidshverdagen. Det kjenner jeg igjen fra support. Der starter jobben alltid med et problem.

Mitt eksempel er backlog-verktøyet jeg har laget i Claude. Det sjekker backloggen og gir en daglig rapport. Det er laget for arbeidshverdagen i support. Jeg kommer tilbake til det senere, for det er det viktigste eksempelet mitt.

Den andre oppgaven er å automatisere arbeidsflyter og koble sammen systemer. Det jeg liker her, er å koble flere steg sammen til en løsning som fungerer.

Eksempelet mitt er en n8n-flyt jeg laget med en WhatsApp-AI. Jeg kunne sende et taleopptak på WhatsApp. Opptaket ble oversatt, og så ble det brukt til å opprette en avtale i kalenderen min. Det som var gøy for meg, var å se stegene henge sammen og bli til noe jeg kunne bruke selv.

Begge eksemplene sier noe om hva slags arbeid jeg trives med og hva jeg gjerne vil gjøre mer av.

*Overgang: Men lyst alene er ikke nok. Det neste spørsmålet er hva jeg tar med meg inn i rollen, og hva jeg fortsatt må lære.*

## 3. Hva jeg tar med meg, og hva jeg må lære · 1,5 min

Grunnlaget mitt har tre deler. Det første er erfaring med brukernes problemer og behov. I support hører jeg hva som skaper problemer for folk i jobben deres.

Det andre er feilsøking, dokumentasjon og kommunikasjon. Jeg er vant til å finne ut hvorfor noe ikke virker, skrive det ned og forklare det for andre på en måte de forstår.

Det tredje er AI-900 og erfaringen fra egne prosjekter.

Samtidig er det ganske tydelig for meg hva som mangler. [BEKREFT: personlig refleksjon] Det neste steget for meg er å lære å ta løsninger fra egne prosjekter til stabil og sikker bruk over tid. Det er stor forskjell på noe som fungerer for meg, og noe som flere skal kunne stole på hver dag. Backlog-verktøyet er et godt eksempel på det. Der må jeg lære mer om testing, feilhåndtering, tilgangsstyring og vedlikehold.

Måten jeg vil lære på, er å jobbe med avgrensede oppgaver. Jeg vil lære sammen med erfarne kolleger, og jeg vil teste, dokumentere og forbedre underveis.

*Overgang: I support starter alt med et problem. Den vanen vil jeg bruke på en tenkt bedrift før jeg viser mer av mitt eget prosjekt.*

## 4. Tre muligheter for en norsk SMB · 3 min

Bedriften jeg bruker her, er fiktiv. Det er en norsk servicebedrift med 25 ansatte. Den har teknikere, administrasjon og kundehenvendelser som kommer inn. Jeg har valgt et oppdiktet eksempel, slik at jeg kan snakke fritt uten å bruke opplysninger om ekte kunder.

Jeg har sett på tre muligheter. For hver av dem har jeg tenkt gjennom oppgaven, hvem som skal bruke den, og hva jeg forventer at den gir. Jeg har prøvd å holde dem enkle.

Den første er en kunnskapsassistent. Oppgaven er å finne informasjon i godkjente rutiner og produktdokumentasjon. Brukerne er teknikere og administrasjon. Ordet «godkjente» er viktig for meg. Assistenten skal bare bygge på innhold som bedriften selv står inne for. Finner den ikke noe, bør den si fra om det. Gevinsten jeg forventer, er mindre leting og mer konsistente svar.

Den andre er en assistent for kundehenvendelser. Den oppsummerer henvendelser og lager svarutkast. Brukerne er kundeservice og administrasjon. Et utkast er bare et utkast. En ansatt kontrollerer alltid svaret før noe sendes til kunden. Her håper jeg på mindre manuelt skrivearbeid og bedre oversikt over det som kommer inn.

Den tredje er en assistent for servicerapporter. Teknikeren har sine notater fra oppdraget, og assistenten lager et strukturert rapportutkast ut fra dem. Teknikeren går gjennom utkastet og retter det før rapporten blir sendt videre. Brukerne er teknikere og administrasjon. Forventet gevinst er enklere dokumentasjon og mindre etterarbeid. Jeg dokumenterer selv i support, så behovet bak denne er lett for meg å forstå.

Felles for alle tre er at et menneske har kontrollen. Assistenten finner informasjon, oppsummerer eller lager utkast. Det er de ansatte som bestemmer hva som blir brukt. Jeg har valgt oppgaver der det er lett å se hvem som bruker løsningen, og hva den skal hjelpe med. Det gjør det også enklere å sjekke om den hjelper i det hele tatt.

Dette er foreslåtte bruksområder for en bedrift som ikke finnes. Alle gevinstene jeg har nevnt, er hypoteser som må undersøkes. Jeg har ingen resultater som viser at de stemmer.

*Overgang: Og ingen bedrift bør starte med alle tre samtidig. Så hvor ville jeg begynt?*

## 5. Startpunkt og hvordan undersøke verdien · 2 min

Mitt forslag er å starte med kunnskapsassistenten i den fiktive bedriften.

Stegene på lysbildet viser rekkefølgen jeg ville fulgt. Først behovet, så avklaring. Deretter en pilot, måling og til slutt en beslutning. Før vi bygger noe, ville jeg sett på hvordan oppgaven løses i dag. Ellers har vi ikke noe å sammenligne med senere.

Hvorfor starte her? Behovet er avgrenset, og vi vet hvem brukerne er. Assistenten kan brukes av både teknikere og administrasjon. Løsningen kan avgrenses til å finne og presentere informasjon. Da blir det også mulig å undersøke både kvalitet og tidsbruk.

Før en pilot er det en del som må avklares. Hvilke spørsmål bruker de ansatte mest tid på? Er dokumentasjonen oppdatert og godkjent? Hvilke tilganger og data kan vi bruke? Og hvem eier innholdet og følger opp løsningen etterpå? Hvis dokumentasjonen er utdatert, hjelper det lite med en assistent som finner den raskt.

Så til verdien. Jeg ville sammenlignet dagens arbeidsmåte med en avgrenset pilot. Jeg ville målt tidsbruk, hvor ofte svarene er riktige og hvor ofte noen må rette dem. Brukerne må også få si hva de mener. Til slutt ville jeg vurdert den nytten vi har dokumentert opp mot kostnadene. Først da kan vi bestemme oss for å gå videre eller la det være. Hvis piloten ikke hjelper, er det også verdt å vite.

*Overgang: Noe av denne tankegangen har jeg fått av å se tilbake på mitt eget prosjekt. Så la meg vise dere backlog-verktøyet.*

## 6. Mitt bidrag: backlog-verktøyet i Claude · 3 min

Dette er eksempelet jeg helst vil fortelle om. Det kommer fra arbeidshverdagen i support.

Oppgaven var å lage et verktøy som sjekker backloggen og gir en daglig rapport. Mitt bidrag var at jeg laget verktøyet i Claude. Resultatet er et verktøy som gir en daglig rapport, og som jeg har delt med kolleger. Den videre effekten er at jeg har inspirert andre til å utforske AI. For min egen del har prosjektet gitt meg mer motivasjon til å jobbe med dette.

Jeg vil gjerne si litt mer om hvordan det ble til.

[BEKREFT: behovet, valget og hva jeg ville gjort annerledes] Først behovet. Jeg ønsket en enklere måte å få daglig oversikt over backloggen på. Det er et ganske hverdagslig behov, men det var der jeg startet.

Så et valg jeg tok underveis. Jeg valgte å starte med oversikt og rapportering. Verktøyet endrer ingen saker. Det ga prosjektet et tydelig og avgrenset formål. I dag ser jeg at det henger sammen med det jeg sa tidligere om tilgangsstyring og sikker bruk. Et verktøy som bare gir oversikt, er lettere å holde kontroll på.

Til slutt, hva jeg ville gjort annerledes i dag. Jeg ville definert fra starten hvordan nytten skulle undersøkes. Jeg ville målt tidsbruken før og etter. Jeg ville kontrollert kvaliteten på rapportene. Og jeg ville samlet mer systematiske tilbakemeldinger fra kollegene jeg delte det med.

Det betyr også at jeg ikke kan si at verktøyet har spart tid eller gjort backloggen mindre. Det har jeg ikke målt. Det er nettopp derfor jeg la så mye vekt på måling på forrige lysbilde.

Nede til høyre på lysbildet står n8n-flyten jeg nevnte i starten, med taleopptak, oversettelse og kalenderavtale. Den var en annen type prosjekt. Der handlet det mer om å få flere steg til å fungere sammen enn om å gi oversikt. Begge deler har lært meg noe om hvordan jeg liker å jobbe. Jeg liker å starte med noe lite som jeg selv har bruk for.

*Overgang: Til nå har jeg snakket mest om hva jeg har laget. Nå vil jeg si litt om hvordan jeg jobber sammen med andre, og der bruker jeg WOW-plakaten vår.*

## 7. WOW og hvordan jeg bidrar til kulturen · 1,5 min

Begge temaene her er hentet fra Digiflows WOW-plakat.

Det første er frihet og ansvar. For meg handler det om å ta initiativ og samtidig ta ansvar for det jeg lager. Jeg har tatt initiativ til å utforske AI gjennom egne prosjekter. Backlog-verktøyet valgte jeg å holde til oversikt, så det ikke endrer saker. I en ny rolle vil jeg kombinere nysgjerrigheten med tydelige rammer. Jeg vil ta ansvar for løsningene jeg lager, også etter at de er tatt i bruk.

Det andre er å lære sammen og dele. For meg handler det om å lære av det som går galt og dele når vi lykkes. Jeg har delt backlog-verktøyet med kolleger og inspirert andre til å utforske AI. Å lære av feil handler også om å si det høyt når noe kunne vært gjort bedre, slik jeg har prøvd å gjøre i dag. Jeg vil fortsette å dele erfaringer og lære sammen med andre.

*Overgang: Til slutt vil jeg samle trådene og si hva jeg ønsker å bidra med.*

## 8. Hva jeg ønsker å bidra med · 1 min

Det første er innsikt fra support og fra brukernes arbeidshverdag. Jeg vet hvordan det ser ut når noe ikke fungerer for den som sitter med det.

Det andre er praktisk nysgjerrighet og erfaringen fra egne AI-prosjekter. AI-900 og prosjektene mine er et utgangspunkt jeg vil bygge videre på.

Det tredje er vilje til å lære og til å utvikle løsninger med konkret nytte.

Det er slik jeg ønsker å gå fra å løse problemer i support til å utvikle AI-løsninger som forbedrer arbeidshverdagen. Med backlog-verktøyet fikk jeg til de to første stegene her nede. Jeg forsto behovet, og jeg laget løsningen. Det tredje steget hoppet jeg over, og det er der jeg har lært mest. Det vil jeg bli bedre på.

Forstå behovet. Utvikle løsningen. Undersøke verdien.

Takk for meg. Jeg svarer gjerne på spørsmål.

## Før intervjuet

Sjekk disse punktene, og les manuset høyt én gang med klokke.

- [ ] De to arbeidsoppgavene på lysbilde 2 stemmer med stillingsannonsen
- [ ] Læringsområdet på lysbilde 3 er ditt eget
- [ ] Behovet, valget og «annerledes i dag» på lysbilde 6 stemmer med det som skjedde
- [ ] Du står inne for de personlige setningene: «Det som var gøy for meg …» (2), «Jeg liker å starte med noe lite …» (6), «Å lære av feil handler også om …» (7) og «Jeg vet hvordan det ser ut …» (8)

Hvis tiden blir knapp, kan du kutte disse avsnittene uten at sammenhengen brytes. Hvert av dem tar omtrent et halvt minutt.

| Lysbilde | Avsnitt som kan kuttes |
|---|---|
| 4 | «Felles for alle tre er at et menneske har kontrollen …» |
| 6 | Avsnittet om n8n-flyten nede til høyre |
| 7 | «Å lære av feil handler også om …» |
