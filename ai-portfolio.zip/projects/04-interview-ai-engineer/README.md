# Interview script: AI Engineer

A 15-minute presentation script (8 slides, about 120 words per minute) for an internal interview for an AI Engineer role. In Norwegian: [`manus.md`](manus.md).

**Live doc:** https://claude.ai/artifact/6BhsURhRvgEdPEygnycTVw (private)

## Problem

I needed to present my move from support to AI Engineer in 15 minutes, with real examples, without overselling what I had done.

## What I built

| Slide | Topic | Time |
|-------|-------|------|
| 1 | From support to AI Engineer | 1 min |
| 2 | What motivates me in the role | 2 min |
| 3 | What I bring, and what I need to learn | 1.5 min |
| 4 | Three opportunities for a (fictional) Norwegian SMB | 3 min |
| 5 | Where to start, and how to test the value | 2 min |
| 6 | My contribution: the backlog tool in Claude | 3 min |
| 7 | Company values and culture | 1.5 min |
| 8 | What I want to contribute | 1 min |

Each section ends with a transition line, a cut list keeps the timing safe, and lines marked **[BEKREFT]** are suggestions I had to confirm as true before using them.

## How AI was used

Claude drafted the script from my notes and examples, kept the timing per slide, and marked every claim it could not verify for me to check. I edited the doc over about 35 revisions.

## What I learned

- **Honesty is a strength in a pitch.** The script says plainly that I did not measure the backlog tool's effect, and uses that as the lesson: understand the need, build the solution, *test the value*.
- **Use a fictional company** to talk about use cases freely without exposing real customer data.
- **Human in control.** All three proposed assistants (knowledge, customer requests, service reports) only find, summarise or draft; a person decides.
