# Rollekonfliktfellen ("The role-conflict trap")

A first-line guide written after a real incident: one user with two roles in a clinical system took down e-prescribing for a whole institution for two weeks. No server was broken. (In Norwegian.)

**Live artifact:** https://claude.ai/artifact/GKLReuyaV8jk9U3RTg5ZMz (private). The customer name and ticket number are removed in this copy.

## Problem

Doctors got "cannot reach the prescribing module server" and the app server logged WMI/permission errors. Everything pointed at the server. We restarted services, escalated to the vendor, and the vendor suggested reinstalling the server. The real cause was a user assigned both an assistant role and a nurse role.

## What I built

A one-page write-up ([`index.html`](index.html)) with:

- the symptoms as users and the server saw them,
- a timeline of the two weeks on the wrong track,
- the actual cause and why the system is fragile (no isolation between one user's roles and the whole service),
- a 5-step checklist to run before escalating the next time.

## How AI was used

I gave Claude the ticket history and my notes. Claude structured it into a timeline, root cause and checklist, and I checked the facts and the checklist against what happened.

## What I learned

- **"Affects everyone at once" is a clue.** It didn't fit a single-user setting at first glance, but it was the signal that the cause was shared configuration, not one PC.
- **Server logs show where something fell over, not why.**
- **Writing it up is how the team learns.** The checklist turns a two-week incident into a two-minute check.
