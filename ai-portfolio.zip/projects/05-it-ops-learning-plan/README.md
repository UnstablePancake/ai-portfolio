# IT Operations Role: Gaps & Learning Plan

A gap analysis for an in-house IT operations generalist role, started 17.10.2026. **Status: in progress.** The role overview is written; the rest is outlined.

**Live doc:** https://claude.ai/artifact/H8HHJTr8P5QRervPFFe62J (private)

## What the role is

An in-house generalist role: you own one company's IT end to end, instead of solving tickets for many customers. The ad lists five areas, with Apple device management weighted first.

| Area | What you do day to day | Main tools |
|------|------------------------|-----------|
| Device management | Buy, enroll, configure, patch, repair and retire Macs and iPhones (plus some Windows) | Apple Business Manager (ABM), Intune, Company Portal |
| Security operations | Triage endpoint and identity alerts, keep the security baseline current | An EDR (not named in the ad), Entra ID Protection, Conditional Access |
| Users and access | Joiners, movers and leavers, MFA, licenses, app access, phone numbers | Microsoft 365 admin center, Entra ID, Teams admin center |
| Networks and meeting rooms | Firewalls, switches and Wi-Fi across several offices; Teams meeting rooms | Cisco Meraki Dashboard, Teams Rooms Pro Management portal |
| Purchasing and inventory | Order hardware and software, track assets and licenses, manage vendors | Asset register, reseller portals, license reports |

## What changes from my current job

In my current job I resolve tickets inside policies someone else designed, with 2nd line behind me. In this role I would be the last line:

- **Depth over breadth.** One tenant, one network, one fleet. You design the policies, not just apply them.
- **Proactive work.** Spot problems before users do: devices out of compliance, certificates about to expire, licenses paid for but unused.
- **Production ownership.** Make changes in the live environment and own testing and rollback.
- **Business-facing.** Budgets, vendors and stakeholders, all in English.

## Planned sections

- [ ] Fit scorecard: each requirement vs my CV, rated strong / partial / gap
- [ ] Apple device management with ABM + Intune: the full device lifecycle
- [ ] Security operations: endpoint and identity alerts, triage, baselines
- [ ] Users, access and telephony: joiner/mover/leaver, SSO, Teams Phone
- [ ] Networks (Cisco Meraki) and Microsoft Teams Rooms
- [ ] Purchasing, inventory, licenses and suppliers
- [ ] 8-week learning plan with weekly labs and outputs
- [ ] Certifications, courses and lab setup options
- [ ] Application: English CV, tailoring, interview stories

## How AI was used

Claude read the job ad and turned it into the table above, then laid out the sections a structured learning plan needs.
